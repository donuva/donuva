
import java.util.ArrayList;

public class Account {
    private double balance;
    private ArrayList<Transaction> transitionList = new ArrayList<Transaction>();

    /**
     * T.
     */
    private void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("So tien ban nap vao khong hop le!");
        }

        this.balance = this.balance + amount;
        this.transitionList.add(new Transaction("deposit", amount, this.balance));
    }

    /**
     * T.
     */
    private void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("So tien ban rut ra khong hop le!");
        }

        if (amount > this.balance) {
            System.out.println("So tien ban rut vuot qua so du!");
        }

        this.balance = this.balance - amount;
        this.transitionList.add(new Transaction("withdraw", amount, this.balance));
    }

    /**
     * T.
     */
    public void addTransaction(double amount, String operation) {
        if (Transaction.DEPOSIT == operation) {
            this.deposit(amount);
            return;
        }

        if (Transaction.WITHDRAW == operation) {
            this.withdraw(amount);
            return;
        }

        System.out.println("Yeu cau khong hop le!");
    }

    /**
     * T.
     */
    public void printTransaction () {
        int num = 0;
        for (Transaction tmp : transitionList) {
            num++;
            //System.out.println(tmp.getOperation() + ", " + tmp.getBalance() + "," + tmp.getAmount());

            if (tmp.getOperation() == "deposit") {
                System.out.print(" Nap tien $");
            } else {
                System.out.print(" Rut tien $");
            }
            System.out.printf("%.2f", tmp.getAmount());
            System.out.print(". So du luc nay: $");
            System.out.printf("%.2f.\n", tmp.getBalance());
        }
    }
}



